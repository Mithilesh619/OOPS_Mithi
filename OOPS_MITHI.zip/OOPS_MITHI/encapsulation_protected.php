<?php

    // class class1{
    //     protected $num;
    //     function __construct(){
    //         $this->num=10;
    //     }
    // }
    // $obj=new class1();
    // $obj->num=2;
    // echo $obj->num;
    // 

    //if we use protected keyword in place of public then this programme is giving error.because protected ka access sirf class ke andar rahataa hai. aur jis class ne
    //aapke class ko access kiya ho wahaa rahataa hai. that means aap class ke baahar num ko access kar rahe ho isliye error de rahaa hai.
    //To solve this error we will use setter and getter.follow below programme.
    //setter value to set kartaa hai 
    //getter value to get kartaa hai.


    // class class1{
    //     protected $num;
    //     function __construct(){
    //         $this->num=10;
    //     }
    //     function getNum(){
    //         return $this->num;
    //     }
    // }
    // $obj=new class1();
    // //echo $obj->num=2;
    // echo $obj->getNum();


    //OR
    
    class class1{
        protected $num;
        function __construct(){
            $this->num=10;
        }   
    }
    class class2 extends class1{
        function getNum(){
            return $this->num;
    }
    }
    $obj=new class2();
    //echo $obj->num=2;
    echo $obj->getNum();


?>