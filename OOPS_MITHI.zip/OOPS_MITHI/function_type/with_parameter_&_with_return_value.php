<?php


// function add($num1,$num2){
//     return $num1 + $num2;

// }
// echo add(2,3)."<br>";
// $rvalue = add(12,12);
// echo $rvalue;


function square($num){
    return $num*$num;
}
echo square(3)."<br>";
$return_value = square(4);
echo $return_value;
?>