<?php

function valueofpi()
{
    return 3.415;
}
echo valueofpi();
?>