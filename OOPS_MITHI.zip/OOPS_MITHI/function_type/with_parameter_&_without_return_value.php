<?php

// function wish($message){
//     echo $message."<br>";
// }
// wish("good morning");
// wish("good night");


function sum($a,$b){
echo $a+$b."<br>";
}
sum(5,6);
sum(50,60);
?>