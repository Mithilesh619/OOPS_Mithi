<?php
function wish()
{
    echo "Hi"."<br>";
}
wish();
wish();
?>