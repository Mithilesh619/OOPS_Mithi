<?php
class class1{
	function fun1(){
		echo "fun1";
	}
	function fun(){
		echo "fun2";
	}
}
$obj=new class1();
$obj->fun1();
echo "<br>";
$obj->fun();
?> 