<?php

// class class1{
//     function __construct()
//     {
//         echo "construct1";
//     }
//     function fun(){
//         echo "Fun1";
//     }
// }
// class class2 extends class1{
 
// }
// $obj = new class2();
// $obj->fun();


class class1{
    function __construct()
    {
        echo "construct1";
    }
    function fun(){
        echo "Fun1";
    }
}
class class2 extends class1{
    function fun2(){
        echo "fun2";
    }

}
$obj = new class2();
$obj->fun();
$obj->fun2();


?>