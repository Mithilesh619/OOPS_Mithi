<?php

// abstract class class1{
//     abstract function test();
// }
// class class2 extends class1{
//     function test(){
//         echo "test";
//     }
// }


abstract class bank{
    abstract function id_proof();
}
class hdfc extends bank{
    function id_proof(){
        echo "test";
    }
}
class icici extends bank{
    function id_proof(){
        echo "test";
    }
}

?>