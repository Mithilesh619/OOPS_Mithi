<?php

// function wow($a){
//     $a = "Hey";
// }
// $str="Hello";
// wow($str);
// echo $str;

// op: Hello


// function wow(&$a){
//     $a = "Hey";
//     //$a .= "Hey";
// }
// $str="Hello";
// wow($str);
// echo $str;

// op: Hey

//======================================

// function testing($string){
//     $string .= " and something extra";
// }

// $str = "This is a string";
// testing($str);
// echo $str;

// op: This is a string



// function testing(&$string){
//     $string .= " and something extra";
// }

// $str = "This is a string";
// testing($str);
// echo $str;

//op: This is a string and something extra



?>