<?php

class test{
    public function say($a){
        return $a;
    }
    public function tell(){
        $c ="Hello World";
        $a = $this->say($c);
        return $a;
    }
}
$b=new test();
echo $b->tell();
?>
