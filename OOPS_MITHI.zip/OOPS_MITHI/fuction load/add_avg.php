<?php
function sum($math,$eng,$sci)
{
    $total=$math+$eng+$sci;
    return $total; 
}
function avg($sum_total)
{
    echo $sum_total/3;
}
//echo sum(11,11,11);
$variable = sum(50,50,51);
echo $variable."<br>";
avg($variable);
?>