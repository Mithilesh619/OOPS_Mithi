<?php

// function f3() {
//     echo "This is the second function.";
// }

// function f4() {
//     f3();
//     echo "This is the first function. ";
//      // Call the second function
// }


// // Call the first function
// f4();


// function functionA() {
//     // Code for function A
//     echo "This is function A.<br>";
// }

// function functionB() {
//     // Code for function B
//     echo "This is function B.<br>";

//     // Call functionA
//     functionA();
// }

// // Call functionB
// functionB();


class MyClass {
    public function functionA() {
        echo "Function A";
    }
    
    public function functionB() {
        echo "Function B";
        $this->functionA(); // Calling functionA within functionB using $this
    }
}

$obj = new MyClass();
$obj->functionB(); // Output: Function B Function A


?>