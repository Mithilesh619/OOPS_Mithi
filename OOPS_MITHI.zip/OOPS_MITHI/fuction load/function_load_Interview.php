<?php

class student{
    function f1(){
        echo "f1";
    }
    function f2(){
        echo "f2";
    }
    function f3(){
        echo "f3";
    }
    function f4(){
        $this->f3();
        
    }
}
$obj= new student();
$obj->f4();

?>