<?php

class student{
    public $x=10;
    function f1(){
        echo $this->x;
    }
    function f2(){
        echo "f2";
    }
}
$obj=new student();
$obj->f1();
$obj->f2();

?>