<?php

// class class1{
//     function __construct(){
//         $this->num=10;
//     }
// }
// $obj=new class1();
// echo $obj->num;

//By default $num is public in class1 above programme . if I declare public $num; in class1 in same programme down. then ouput will be same. 



// class class1{
//     public $num;
//     function __construct(){
//         $this->num=10;
//     }
// }
// $obj=new class1();
// echo $obj->num;

//that means both above programme is same.


//if i do like this:

    class class1{
        public $num;
        function __construct(){
            $this->num=10;
        }
    }
    $obj=new class1();
    $obj->num=2;
    echo $obj->num;

    //if declared variable is public then i can access the variable  and  can change the  variable value outside of class which is wrong.
    //anyone should not be able to change the value.so to do this we use protected in place of public keyword. follow encapsulation_protected programme to handle this.



?>