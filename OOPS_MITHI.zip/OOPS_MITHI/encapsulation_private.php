<?php

// class class1{
//     protected $num;
//     function __construct(){
//         $this->num=10;
//     }   
// }
// class class2 extends class1{
//     function getNum(){
//         return $this->num;
// }
// }
// $obj=new class2();
// //echo $obj->num=2;
// echo $obj->getNum();

//above programme is protected. At the place of protected we will use private keyword in below programme.

class class1{
    private $num;
    function __construct(){
        $this->num=10;
    }   
}
class class2 extends class1{
    function getNum(){
        return $this->num;
}
}
$obj=new class2();
//echo $obj->num=2;
echo $obj->getNum();

//above programme will give error. because private ka access sirf class ke ander rahataa hai.naa to class ke bahar aur naa hi wahaan jahaa jis class ne aapke class ko
//access kiya ho.


?>