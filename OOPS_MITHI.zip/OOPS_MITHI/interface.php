<?php


// interface class1{
//     public function test1();
// }
// interface class2{
//     public function test2();
// }
// class class3 implements class1,class2{
//     public function test1(){
//     }
//     public function test2(){
//     }
// }



interface class1{
     function test1();
}
interface class2{
     function test2();
}
class class3 implements class1,class2{
     function test1(){
        echo "test1";
    }
     function test2(){
        echo "test2";
    }
}
$obj=new class3();
$obj->test1();
$obj->test2();


//if i try to create object of interface class then it will give error. that means we can't create object of abstract class.
//$obj2=new class1();


?>