<?php


//why need of trait?
//initially we were coding like this.

// class class1{
//     function fun1(){
//         echo "Fun1";
//     }
// }
// class class2 extends class1{
//     function fun2(){
//         echo "Fun2";
//     }
// }
// class class3 extends class2{
//     function fun3(){
//         echo "Fun3";
//     }
// }
// class class4 extends class3{
//     function fun4(){
//         echo "Fun4";
//     }
// }

// $obj=new class3();
// //$obj->fun1();
// $obj->fun2();
 
//ideally class3 ko fun2() ki requirement hai. fun1() ki nahi. but class3 fun1() ko bhi acess kar paa rahaa hai.
//iska solution hai trait.so the code will be like this below.

trait class1{
    function fun1(){
        echo "Fun1";
    }
}
class class2{
    use class1;
    function fun2(){
        echo "Fun2";
    }
}
class class3 extends class2{
    function fun3(){
        echo "Fun3";
    }
}
class class4 extends class3{
    use class1;
    function fun4(){
        echo "Fun4";
    }
}

$obj=new class2();
$obj->fun1();


?>