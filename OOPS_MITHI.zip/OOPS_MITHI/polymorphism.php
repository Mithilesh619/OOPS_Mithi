<?php

//polymorphism can be achieve by 2 ways:
//1. abstract class ke through.
//2. interface ke through.


//1. abstract class ke through.
//in abstract class, we can create both abstract method (i.e. only function declaration) as well as normal method.

// abstract class class1{
// abstract function fun1();
// }
// class class2 extends class1{
//     function fun1(){
//         echo "Fun1";
//     }
// }
// class class3 extends class1{
//     function fun1(){
//         echo "Fun2";
//     }
// }

// $obj=new class2();
// $obj->fun1();
// echo "<br>";

// $obj=new class3();
// $obj->fun1();

//function ka naam same hai but output alag alag hai. i.e. polymorphism.


//2. interface ke through.
//in interface class, we can create  only function declaration i.e (abstract method/incomplete method) not normal method.


interface class1{
function fun1();
}
class class2 implements class1{
    function fun1(){
        echo "Fun1";
    }
}
class class3 implements class1{
    function fun1(){
        echo "Fun2";
    }
}

$obj=new class2();
$obj->fun1();
echo "<br>";

$obj=new class3();
$obj->fun1();


?>

