<?php

// class student{
//     function __construct(){
//         echo "start";
//     }
//     function __destruct(){
//         echo "end";
//     }
// }
// $obj=new student();


// class student{
//     function __construct(){
//         echo "start";
//     }
//     function f1(){
//         echo "f1";
//     }
//     function __destruct(){
//         echo "end";
//     }
// }
// $obj=new student();


// class student{
//     function __construct(){
//         echo "start";
//     }
//     function f1(){
//         echo "f1";
//     }
//     function __destruct(){
//         echo "end";
//     }
// }
// $obj=new student();
// $obj->f1();


//you can change the order also.but first construct will execute then function then destruct will be execute.

class student{
    
    function f1(){
        echo "f1";
    }
    function __destruct(){
        echo "end";
    }
    function __construct(){
        echo "start";
    }
}
$obj=new student();
$obj->f1();



?>