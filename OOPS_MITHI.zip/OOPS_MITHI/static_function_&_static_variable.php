<?php

// call static function

// class class1{
//     static public $num=10;
//     static function fun1(){
//         echo "test";
//     }
// }
// class1::fun1();



//call static variable
//variable ko call karte time echo karna padtaa hai class ke baahar.function ko nahi. Kyonki funtion ke ander alreay echo rahaa hai.

// class class1{
//     static public $num=10;
//     static function fun1(){
//         echo "test";
//     }
// }
// echo class1::$num;


//call static variable in static function

class class1{
    static public $num=10;
    static function fun1(){
        echo self::$num++;
    }
}
echo "a";
echo class1::$num;
echo "b";
class1::fun1();
echo "c";
echo class1::$num;

//function ke pahale variable ko echo karenge to value 10 rahti hai. 
//but function ko call karne ke baad echo karenge to 1 increment ho jaata hai.aur value 11 ho jaati hai. 
?>